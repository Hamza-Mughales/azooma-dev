<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<div style=" background-color:#00A2B1; width:100% !important; margin-top:30px;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
<tr>
<td height="1px">&nbsp;&nbsp;</td>
</tr>
<tr>
<td>

<table align="center" width="600px" style=" background-color:#FFFFFF;">
			<tr>
            <td colspan="2" align="left" style="padding-left:10px;" valign="top"><img src="<?php echo base_url();?>images/emailLogo.jpg" alt="Sufrati.com" /></td>
            </tr>
            
            <tr>
			<td align="left" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; padding-left:10px; padding-right:10px; padding-top:12px;" colspan="2"><h1>Welcome To Sufrati.com</h1></td>
			</tr> 
            
            <tr>
			<td align="left" style="font-family:Arial, Helvetica, sans-serif; font-size:12px;padding-left:10px; padding-right:10px;" colspan="2"><h2>Dear <?php echo ucwords($restname); ?></h2></td>
			</tr> 
            
            <tr>
            <td colspan="2" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; padding-left:10px; padding-right:10px;" >
           Thank you for your payment which has been received with Reference# <?php echo $referenceNo;?><br/>
           We have upgraded your account.
            </td>
                     
            
            <tr>
            <td style="font-family:Arial, Helvetica, sans-serif; font-size:12px; padding-left:10px; padding-right:10px; color:#00A2B1;" width="35%"><strong>Your Account Sart Date is: </strong></td>
    <td width="65%" style="font-family:Arial, Helvetica, sans-serif; font-size:12px;color:#00A2B1; padding-left:10px; padding-right:10px;">
    <strong><?php echo $memDate; ?></strong></td>
    </tr>
    
            
			<tr>
            <td style="font-family:Arial, Helvetica, sans-serif; font-size:12px; padding-left:10px; padding-right:10px;color:#00A2B1;" width="35%"><strong>Your Account will be active for: </strong></td>
            <td style="font-family:Arial, Helvetica, sans-serif; font-size:12px; padding-left:10px; padding-right:10px;color:#00A2B1;" width="65%"><strong><?php echo $duration;?></strong></td>
    		</tr>
            			
               <tr>
<td colspan="2" height="50px;">&nbsp;&nbsp;</td>
</tr> 
<tr>
				<td align="left" valign="top" height="160px" colspan="2" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; padding-left:10px; padding-top:10px; color:#FFFFFF; background-color:#000000;">
                                
                                <strong>Sufrati.Com<br />
                                </strong>P.O.Box 15780<br />
                                Jeddah 21454<br />
                                Kingdom of Saudi Arabia<br />
                                <br />
                                Telephone: <a rel="nofollow" style="color:#FFFFFF;">+966 2 6687892</a><br />
                                Fax: <a rel="nofollow" style="color:#FFFFFF;">+966 2 6687893</a><br />
                                Email:<a rel="nofollow" style="color:#FFFFFF;">info@azooma.co</a>
                                </td>
			</tr>

            
            </table>

</td>
</tr>

                        
<tr>
<td height="50px;">&nbsp;&nbsp;</td>
</tr>			   									  
														  										  
		</table>
</div>

</body>
</html>
