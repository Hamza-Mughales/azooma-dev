<?php $img_url = base_url()."images/"; ?>

<div id="data-table">
  <div class="preset_left">
    <h2>Choose the right Sufrati.com account for you</h2>
    <table class="style1 datatable" width="450px">
      <thead>
        <tr>
          <th width="130px">Features</th>
          <th class="actv">Bronze</th>
          <th class="actv">Silver</th>
          <th class="actv" colspan="2">Gold</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Profile Page</td>
          <td align="center"><a href="#" class="someClass" title="Add and update all your business details and contact information."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16"  alt="Restaurant Info" /></a></td>
          <td align="center"><a href="#" class="someClass" title="Add and update all your business details and contact information."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16"  alt="Restaurant Info" /></a></td>
          <td align="center" colspan="2"><a href="#" class="someClass" title="Add and update all your business details and contact information."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16"  alt="Restaurant Info" /></a></td>
        </tr>
        <tr>
          <td>Branch Managment</td>
          <td align="center"><a class="someClass" href="#" title="Add and update branch location info, maps and more..."> <img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="Branches" /></a></td>
          <td align="center"><a class="someClass" href="#" title="Add and update branch location info, maps and more..."> <img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="Branches" /></a></td>
          <td align="center"  colspan="2"><a class="someClass" href="#" title="Add and update branch location info, maps and more..."> <img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="Branches" /></a></td>
        </tr>
        <tr>
          <td>Menu</td>
          <td align="center"><a class="someClass" href="#" title="Add all your menu Items + add your PDF for customers to download."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="Branches" /></a></td>
          <td align="center"><a class="someClass" href="#" title="Add all your menu Items + add your PDF for customers to download."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="Branches" /></a></td>
          <td align="center"  colspan="2"><a class="someClass" href="#" title="Add all your menu Items + add your PDF for customers to download."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="Branches" /></a></td>
        </tr>
        <tr>
          <td>Photo Gallery</td>
          <td align="center"><a class="someClass" href="#" title="Add and View 6 photos"><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /></a></td>
          <td align="center"><a class="someClass" href="#" title="Add and View 12 photos"><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /></a></td>
          <td align="center"  colspan="2"><a class="someClass" href="#" title="Add and View 20 photos"><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /></a></td>
        </tr>
        <tr>
          <td>News Feeds</td>
          <td align="center"><a class="someClass" href="#" title="Your Updates will appear on sufrati.com News Feed on home page eg. When you change your menu, images, offers, contact numbers."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /></a></td>
          <td align="center"><a class="someClass" href="#" title="Your Updates will appear on sufrati.com News Feed on home page eg. When you change your menu, images, offers, contact numbers."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /></a></td>
          <td align="center"  colspan="2"><a class="someClass" href="#" title="Your Updates will appear on sufrati.com News Feed on home page eg. When you change your menu, images, offers, contact numbers."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /></a></td>
        </tr>
        <tr>
          <td>Add Special Offers</td>
          <td align="center"><img src="<?php echo base_url(); ?>images/account/ico_inactive_16.png" class="icon16" alt="" /></td>
          <td align="center"><a class="someClass" href="#" title="Display your Latest Offer on your profile page and in sufrati.com’s Special offers page instantly."> <img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /> </a></td>
          <td align="center"  colspan="2"><a class="someClass" href="#" title="Display your Latest Offer on your profile page and in sufrati.com’s Special offers page instantly."> <img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /> </a></td>
        </tr>
        <tr>
          <td>Comment Response</td>
          <td align="center"><img src="<?php echo base_url(); ?>images/account/ico_inactive_16.png" class="icon16" alt="" /></td>
          <td align="center"><a class="someClass" href="#" title="Respond to important customer comments both good and bad."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /></a></td>
          <td align="center"  colspan="2"><a class="someClass" href="#" title="Respond to important customer comments both good and bad."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /></a></td>
        </tr>
        <tr>
          <td>Fan Club</td>
          <td align="center"><img src="<?php echo base_url(); ?>images/account/ico_inactive_16.png" class="icon16" alt="" /></td>
          <td align="center"><img src="<?php echo base_url(); ?>images/account/ico_inactive_16.png" class="icon16" alt="" /></td>
          <td align="center"  colspan="2"><a class="someClass" href="#" title="Fans will receive instant notifications direct to their emails and sufrati.com accounts about your latest updates eg. Menu, images, offers, contact numbers."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="Restaurant Info" /></a></td>
        </tr>
        <tr>
          <td>Video Upload</td>
          <td align="center"><img src="<?php echo base_url(); ?>images/account/ico_inactive_16.png" class="icon16" alt="" /></td>
          <td align="center"><img src="<?php echo base_url(); ?>images/account/ico_inactive_16.png" class="icon16" alt="" /></td>
          <td align="center"  colspan="2"><a class="someClass" href="#" title="Attract your customers with Video’s on your page."> <img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /></a></td>
        </tr>
        <tr>
          <td>Create Polls</td>
          <td align="center"><img src="<?php echo base_url(); ?>images/account/ico_inactive_16.png" class="icon16" alt="" /></td>
          <td align="center"><img src="<?php echo base_url(); ?>images/account/ico_inactive_16.png" class="icon16" alt="" /></td>
          <td align="center"  colspan="2"><a class="someClass" href="#" title="Create polls and find out what your visitors think."><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /></a></td>
        </tr>
        <tr>
          <td>Online Bookings</td>
          <td align="center"><img src="<?php echo base_url(); ?>images/account/ico_inactive_16.png" class="icon16" alt="" /></td>
          <td align="center"><img src="<?php echo base_url(); ?>images/account/ico_inactive_16.png" class="icon16" alt="" /></td>
          <td align="center"  colspan="2"><a class="someClass" href="#" title="Available for Gold in Early 2012"><img src="<?php echo base_url(); ?>images/account/ico_active_16.png" class="icon16" alt="" /></a></td>
        </tr>
        <tr>
          <td colspan="6">&nbsp;</td>
        </tr>
      </tbody>
    </table>
  </div>
  <div class="preset_right">
    <h2>Select an account</h2>
    <form id="accountForm" action="<?php echo base_url(); ?>accounts/savepreset" method="post">
      <table class="style1 datatable" width="450px">
        <thead>
          <tr>
            <th class="actv">Bronze</th>
            <th class="actv">Silver</th>
            <th class="actv">Gold</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td align="center"><input class="required"  type="radio" name="preset" id="preset" value="0" /></td>
            <td align="center"><input type="radio" name="preset" id="preset" value="1" /></td>
            <td align="center"><input type="radio" name="preset" id="preset" value="2" /></td>
          </tr>
        </tbody>
      </table>
      <h2>Select Duration</h2>
      <table class="style1 datatable" width="450px">
        <thead>
          <tr>
            <th class="actv"><strong>1 Year</strong></th>
            <th class="actv"><strong>2 Years</strong></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td align="center"><input class="required" type="radio" name="duration" id="duration" value="12"></td>
            <td align="center"><input type="radio" name="duration" id="duration" value="24"></td>
          </tr>
        </tbody>
      </table>
      <h2>Are You Interested in.</h2>
      <table class="style1 datatable" width="450px">
        <tbody>
          <tr>
            <td><input type="checkbox" name="addservices[]" value="HD Video Services" id="hd"/>
              <label for="hd">HD Video Services</label>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <input type="checkbox" name="addservices[]" value="Web Designing & Development" id="web" />
              <label for="web">Web Designing & Development</label>
              <input type="checkbox" name="addservices[]" value="Menu Design" id="menu" />
              <label for="menu">Menu Design</label>
              <br/>
              <input type="checkbox" name="addservices[]" value="Photography Services" id="photo" />
              <label for="photo">Photography Services</label>
              <input type="checkbox" name="addservices[]" value="Branding" id="brand" />
              <label for="brand">Branding</label></td>
          </tr>
        </tbody>
      </table>
      <h2>Do you have any questions?</h2>
      <table class="style1 datatable" width="450px">
        <tbody>
          <tr>
            <td><textarea name="msg" id="msg" cols="45" rows="3" style="width:98%"></textarea></td>
          </tr>
          <tr>
            <td><input type="submit" class="button blue fr" value="Submit" /></td>
          </tr>
        </tbody>
      </table>
    </form>
  </div>
</div>
